new fullpage('#fullpage', {
	licenseKey: "EADE31E7-0A0A42C3-A91F5552-015353DF",
	sectionsColor: ['#fffff', '#fffff', '#b4995a', '#9c9c9c', '#b4985a', '#721216', '#7bc3ea','#9c9c9c',  '#7bc3ea'],
	anchors: ['firstSlide', 'secondSlide', 'thirdSlide', 'fourthSlide', 'fifthSlide','sixthSlide','seventhSlide','eighthSlide'],
  
    loopBottom: true,
  	autoScrolling:true,
	scrollHorizontally: true,
	continuousHorizontal: true,
	offsetSections: true,
  	navigationTooltips: ['slide1','slide2'],
	navigation: false,
	slidesNavigation: true,
	scrollBar: true,
	showActiveTooltip: false,
	scrollbar: true,
	responsiveWidth: 1000,
	fitToSectionDelay: 500,
	resetSliders: true,
  
});

// The following code is from https://www.w3schools.com/howto/howto_js_scroll_to_top.asp 


mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0; // For Safari
  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}
